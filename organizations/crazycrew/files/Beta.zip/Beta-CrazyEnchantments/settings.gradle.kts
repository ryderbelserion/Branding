rootProject.name = "CrazyEnchantments"

enableFeaturePreview("VERSION_CATALOGS")