package com.badbones69.crazyenchantments.api.support.interfaces.claims;

import org.bukkit.entity.Player;

public interface PlotSquaredVersion {
    
    boolean inTerritory(Player player);
    
}