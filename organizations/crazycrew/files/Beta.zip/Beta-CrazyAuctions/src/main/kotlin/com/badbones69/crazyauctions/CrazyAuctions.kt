package com.badbones69.crazyauctions

import org.bukkit.plugin.java.JavaPlugin

class CrazyAuctions : JavaPlugin() {

    private val plugin = this;

    override fun onEnable() {

    }

    override fun onDisable() {

    }

    fun getPlugin() = plugin
}