package com.badbones69.crazyauctions.commands

class BaseCommand {

}