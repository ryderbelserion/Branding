rootProject.name = "CrazyAuctions"

enableFeaturePreview("VERSION_CATALOGS")