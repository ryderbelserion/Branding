## Crazy Envoys

[![Join us on Discord](https://img.shields.io/discord/182615261403283459.svg?label=&logo=discord&logoColor=ffffff&color=7389D8&labelColor=6A7EC2)](https://discord.badbones69.com)

[![CrazyEnvoy's Stargazers](https://img.shields.io/github/stars/Crazy-Crew/Crazy-Envoys?label=stars&logo=github)](https://github.com/Crazy-Crew/Crazy-Envoys/stargazers)
[![CrazyEnvoy's Forks](https://img.shields.io/github/forks/Crazy-Crew/Crazy-Envoys?label=forks&logo=github)](https://github.com/Crazy-Crew/Crazy-Envoys/network/members)
[![CrazyEnvoy's Watchers](https://img.shields.io/github/watchers/Crazy-Crew/Crazy-Envoys?label=watchers&logo=github)](https://github.com/Crazy-Crew/Crazy-Envoys/watchers)

CrazyEnvoys is a plugin that drops custom crates with any prize you want all over spawn for players to fight over.

## Contact
[![Join us on Discord](https://img.shields.io/discord/182615261403283459.svg?label=&logo=discord&logoColor=ffffff&color=7389D8&labelColor=6A7EC2)](https://discord.badbones69.com)

Join us on [Discord](https://discord.badbones69.com)

## Downloads
[![Build Status](https://jenkins.badbones69.com/view/Stable/job/CrazyEnvoys/badge/icon)](https://ci.badbones69.com/view/Stable/job/CrazyEnvoys/)

Downloads can be obtained from the [spigot page](https://www.spigotmc.org/resources/crazy-envoys.32870/) or the [Jenkins](https://ci.badbones69.com/view/Stable/job/CrazyEnvoys/).

## Plugin Data
[![bStats Graph Data](https://bstats.org/signatures/bukkit/CrazyEnvoy.svg)](https://bstats.org/plugin/bukkit/CrazyEnvoy/4537)

## API
In Progress.

### Dependency Information

#### Maven
In Progress.

#### Gradle
In Progress.

## Working with CrazyEnvoys.

#### Contributing
Fork the project & open a pull request.

#### Compiling
Clone the project & run the install task.
