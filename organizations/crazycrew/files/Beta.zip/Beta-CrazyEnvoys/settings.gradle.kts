rootProject.name = "CrazyEnvoys"

enableFeaturePreview("VERSION_CATALOGS")