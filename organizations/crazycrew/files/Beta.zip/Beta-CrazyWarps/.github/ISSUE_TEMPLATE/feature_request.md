---
name: Feature Request
about: Request a feature by creating a new issue.
title: "[Feature] "
labels: 'feature'
assignees: ''

---

**Description of Feature**
A clear and concise description of the requested feature.
